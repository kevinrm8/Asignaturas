package Entrega97StreetFighter;

public class Escenario {

	private String escenario;
	
	
	
	public Escenario(String esc) {
		escenario = esc;
	}
	
	public String getNombreEsc() {
		return escenario;
	}
}
