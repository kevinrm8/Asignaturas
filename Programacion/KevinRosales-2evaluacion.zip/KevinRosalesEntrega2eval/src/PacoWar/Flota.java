package PacoWar;

import java.util.*;
/* 
 * Nombre: kevin
 * Fecha: 26/02/2020
 * */
public class Flota {
	String nombre;
	ArrayList<Nave> Flota = new ArrayList<Nave>();
	
	public Flota(String nombre) {
		this.nombre = nombre;
	}
}
