
public class Ejercicio3 {

	public static void main(String[] args) {
		String NIF="35595677A";
		String Nombre="Kevin";
		String Fecha_nacimiento="31/07/92";
	}

}
