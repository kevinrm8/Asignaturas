
public class Ejercicio4 {

	/* Nombre: Kevin
	 * Fecha:02/10/19
	 * Descripcion: Primeros programas
	 * 
	 * */
	public static void main(String[] args) {
		int var=3;
		
		System.out.println(+var+"x1 = "+(var*1));
		System.out.println(+var+"x2 = "+(var*2));
		System.out.println(+var+"x3 = "+(var*3));
		System.out.println(+var+"x4 = "+(var*4));
		System.out.println(+var+"x5 = "+(var*5));
		System.out.println(+var+"x6 = "+(var*6));
		System.out.println(+var+"x7 = "+(var*7));
		System.out.println(+var+"x8 = "+(var*8));
		System.out.println(+var+"x9 = "+(var*9));
		System.out.println(+var+"x10 = "+(var*10));
		

	}
}
