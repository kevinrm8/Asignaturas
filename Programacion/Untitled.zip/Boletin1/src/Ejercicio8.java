
public class Ejercicio8 {
	/* Nombre: Kevin
	 * Fecha:02/10/19
	 * Descripcion: Operaciones.
	 * 
	 * */

	public static void main(String[] args) {
		int a=2; int b=4;
		System.out.println("Bienvido a mi calculadora");
		System.out.println("El valor de a es ="+a);
		System.out.println("el valor de b es ="+b);
		System.out.println("a+b=" +(a+b));
		System.out.println("a-b=" +(a-b));
		System.out.println("axb=" +(a*b));
		System.out.println("a/b=" +(a/b));
		System.out.println("a%b=" +(a%b));	
	}

}
