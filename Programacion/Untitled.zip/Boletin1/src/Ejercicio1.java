
public class Ejercicio1 {

	public static void main(String[] args) {
		int anyo = 2019;
		int anyo_sig =2020;
		
		System.out.println("Buenas noches. En estos días tan especiales a finales del año "+anyo+  " en los que siempre nos deben unirlos mejores sentimientos os deseo, junto a la Reina y nuestras hijas, una Feliz Navidad y que en el próximo año " + (anyo + 1) + " podáis ver cumplidos vuestros anhelos y aspiraciones");
			
	}
}
