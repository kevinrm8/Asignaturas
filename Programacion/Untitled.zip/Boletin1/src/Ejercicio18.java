
import java.util.Scanner;

public class Ejercicio18 {

	/* Nombre: Kevin
	 * Fecha:04/10/19
	 * Descripcion: Gastar muchas veces el \t
	 * */
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Español\t\t\t\t\tIngles\n");
		
		System.out.println("Hola\t\t\t\t\tHello");
		System.out.println("Adios\t\t\t\t\tBy");
		System.out.println("Agua\t\t\t\t\tWater");
		System.out.println("Tarta de queso\t\t\t\tCheescake");
		System.out.println("Tablet\t\t\t\t\tLaptot");
		System.out.println("Reloj\t\t\t\t\tSmartwatch");
		System.out.println("Teclado\t\t\t\t\tkeyboard");
		System.out.println("Campeonat\t\t\t\tChampionship");
		System.out.println("Raton\t\t\t\t\tMouse");
		System.out.println("Tarjeta Grafica\t\t\t\tGraphic card");

	}
}
