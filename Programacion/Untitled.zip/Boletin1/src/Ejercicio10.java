
public class Ejercicio10 {
	/* Nombre: Kevin
	 * Fecha:02/10/19
	 * Descripcion:  Calculamos el % de niños y niñas en el aula
	 * 
	 * */

	public static void main(String[] args) {
		float niños =21; float niñas = 2; float total=0;
		total= niños + niñas;
		System.out.println("Tenemos matriculados "+niños+" niños y "+niñas+" niñas. En total, tenemos mariculados "+total+" alumnos, siendo un "+((niños/total)*100)+ " perteneciente a los niños y "+((niñas/total)*100)+" perteneciente a las niñas.");
		
	}

}
