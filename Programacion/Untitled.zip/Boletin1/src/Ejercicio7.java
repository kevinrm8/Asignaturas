
public class Ejercicio7 {
	/* Nombre: Kevin
	 * Fecha:02/10/19
	 * Descripcion: Intercanviar numero a por b y mostrarlo por pantalla
	 * 
	 * */

	public static void main(String[] args) {
		
		int a=2; int b=3; int c=0;
		System.out.println("Al principio del programa, el valor de a es "+a+" y el valor de b es "+b+".");
		c=a;
		a=b;
		b=c;
		System.out.println(" Despues del intercanvio, el valor de a es "+a+" y el valor de b es "+b+".");
	}

}
